$(document).ready(function(){
    $("#recent-recipes-button").click(function(){
        $("#recent-recipes").toggle("slow");
    });
    $("#easy-recipes-button").click(function () {
        $("#easy-recipes").toggle("slow");
    });

});
const StepHighlighter = {
    listItems: document.querySelectorAll('.step'),
    highlight(item) {
        item.style.backgroundColor = "#ffd68f";
    },
    reset(item) {
        item.style.backgroundColor = "#FD8D14"; 
    },
    attachEvents() {
        this.listItems.forEach(item => {
            item.addEventListener('mouseover', () => this.highlight(item));
            item.addEventListener('mouseout', () => this.reset(item));
        });
    },
};

StepHighlighter.attachEvents();

const links = [
    { name: 'YouTube  ', url: 'https://www.youtube.com', icon: 'fab fa-youtube' },
    { name: 'Instagram', url: 'https://www.instagram.com', icon: 'fa-brands fa-instagram' }
];

document.getElementById('usefulLinks').addEventListener('keypress', function(event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        displayLinks();
    }
});

function displayLinks() {
    const linkContainer = document.getElementById('linkContainer');
    linkContainer.innerHTML = links.map(link =>
        `<a href="${link.url}" target="_blank"><i class="${link.icon}"></i> ${link.name}</a>`
    ).join('');
    linkContainer.style.display = 'block';
}
var myAudio = document.getElementById("myAudio");

function playAudio() {
    myAudio.play();
}

function pauseAudio() {
    myAudio.pause();
}